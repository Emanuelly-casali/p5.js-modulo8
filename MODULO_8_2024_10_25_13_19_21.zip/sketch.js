let palavra;

function setup() {
  createCanvas(400, 400); // criando cenário;
  
  palavra = palavraAleatoria();
  
  
}
function palavraAleatoria() {
let palavras = ["caminhante", "caminho", "caminha"];
 return random (palavras);// criando variável palavra = caminhante
}

function inicializaCores (){// função para definir a cor do cenario
  background(220); // cor do cenário
  fill("black");// cor da letra
  textSize(64);// tamanho do texto
  textAlign(CENTER, CENTER);// centralizar o texto
}

function palavraParcial(minimo, maximo) {
  let quantidade = map(mouseX, minimo, maximo, 1, palavra.length); //criando variável quantidade
 let parcial = palavra.substring(0, quantidade);// criando variável parcial
  return parcial;
}

function draw() { // função de desenho
  inicializaCores();
 
  let texto = palavraParcial(0, width);
  text(texto, 200, 200);

  }